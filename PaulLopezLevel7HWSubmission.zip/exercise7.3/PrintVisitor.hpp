#ifndef PRINTVISITOR_HPP
#define PRINTVISITOR_HPP
#include "ShapeVisitor.hpp"
#include "Shape.hpp"
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "ShapeComposite.hpp"

namespace PAULLOPEZ {
	namespace CAD {

		class PrintVisitor : public ShapeVisitor {

		public:
			void visit(Point& p);
			void visit(Line& l);
			void visit(Circle& c);
			void visit(ShapeComposite& sc);
		};

	}
}

#endif