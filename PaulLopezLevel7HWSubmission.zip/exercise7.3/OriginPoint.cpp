#ifndef OriginPoint_CPP
#define OriginPoint_CPP
#define _USE_MATH_DEFINES
#include "Point.hpp"
#include "OriginPoint.hpp"
#include <cmath>
#include <sstream>

namespace PAULLOPEZ {
	namespace CAD {
		OriginPoint::OriginPoint() {
			//std::cout << "OriginPoint ctor." << std::endl;
		}

	}//namespace CAD
} //namespace PAULLOPEZ


#endif
