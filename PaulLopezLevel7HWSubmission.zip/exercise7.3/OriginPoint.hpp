#ifndef OriginPoint_HPP
#define OriginPoint_HPP
#include "Shape.hpp"
#include "Point.hpp"
#include "Singleton.hpp"

namespace PAULLOPEZ {
	namespace CAD {
		class OriginPoint:public Singleton<Point> {
		public:
			OriginPoint(); 

			OriginPoint(const OriginPoint& srcPt) = delete;    // copy constructor
			OriginPoint& operator = (const OriginPoint& srcPt) = delete;// Assignment operator

		};
		
	}
}
#endif