#ifndef PRINTVISITOR_CPP
#define PRINTVISITOR_CPP
#include "PrintVisitor.hpp"
#include "Shape.hpp"
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "ShapeComposite.hpp"


namespace PAULLOPEZ {
	namespace CAD {
		void PrintVisitor::visit(Point& p) {
			//std::cout << "Point Visit: " << std::endl;
			p.Print();
		}

		void PrintVisitor::visit(Line& l) {
			//std::cout << "Line Visit: " << std::endl;
			l.Print();
		}

		void PrintVisitor::visit(Circle& c) {
			//std::cout << "Circle Visit: " << std::endl;
			c.Print();
		}

		void PrintVisitor::visit(ShapeComposite& sc) {
			std::cout << "Shape Composite Visit: " << std::endl;
			for (auto it = sc.begin(); it != sc.end(); it++) {
				(*it)->Print();
				std::cout << "\n";
			}
			std::cout << "\n";
		}
		
		



	}
}

#endif