#ifndef SHAPEVISITOR_HPP
#define SHAPEVISITOR_HPP
#include "Shape.hpp"
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "ShapeComposite.hpp"

namespace PAULLOPEZ {
	namespace CAD {

		class ShapeVisitor {

		public:
			
			virtual void visit(Point& p) = 0;
			virtual void visit(Line& l) = 0;
			virtual void visit(Circle& c) = 0;
			virtual void visit(ShapeComposite& sc) = 0;

			// Point translate(Point& p, double d);
			//virtual Line translate(Line& p, double d);
			//virtual Circle translate(Circle& p, double d);
		};

	}
}

#endif