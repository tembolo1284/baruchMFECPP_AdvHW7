#ifndef SHAPEFACTORY_HPP
#define SHAPEFACTORY_HPP
#include <iostream>
#include <string>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "PolyLine.hpp"
#include <memory>


namespace PAULLOPEZ {
	namespace CAD {

		class ShapeFactory {

		public:

			virtual std::shared_ptr<Circle> CreateCircle() = 0;
			//virtual void CreateCircle(double rad, Point& p) = 0;

			virtual std::shared_ptr<Line> CreateLine() = 0;
			//virtual void CreateLine(Point& p1, Point& p2) = 0;

			virtual std::shared_ptr<Point> CreatePoint() = 0;

			virtual std::tuple<Point, Line, Circle> CreateShapes() = 0;

			virtual ~ShapeFactory() {}
		};
	}
}

#endif