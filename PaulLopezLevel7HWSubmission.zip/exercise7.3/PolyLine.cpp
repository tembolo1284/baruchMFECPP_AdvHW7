#ifndef PolyLine_CPP
#define PolyLine_CPP
#define _USE_MATH_DEFINES
#include "PolyLine.hpp"
#include "ConsoleShapeFactory.hpp"
#include <cmath>
#include <sstream>
#include <memory>
using namespace std;

namespace PAULLOPEZ {
	namespace CAD {
		
		template<template<typename, typename> class Container, typename alloc>
		PolyLine<Container, alloc>::PolyLine() {
			//cout << "Default Polyline constructor says hello to you." << endl;
		}

		template<template<typename, typename> class Container, typename alloc>
		PolyLine<Container, alloc>::PolyLine(int num, std::shared_ptr<Point> p) {
			//cout << "This is another POINT constructor." << endl;
			int counter{ 0 };
			while (counter < num) {
				*this->m_ptContainer.push_back(p);
				//*this->AddShape(dynamic_cast<Point>(p));
				counter++;//add num points p
			}
		}

		template<template<typename, typename> class Container, typename alloc>
		PolyLine<Container, alloc>::~PolyLine() {
			//cout << "See you later POINT..." << endl;
		}
		
		template<template<typename, typename> class Container, typename alloc>
		string PolyLine<Container, alloc>::ToString() const {
			std::string s = Shape::ToString();
			stringstream pnt;
			pnt << s;
			auto it = ShapeComposite::m_shapeList.begin();
			auto it2 = m_ptContainer.begin();
			auto it2End = m_ptContainer.end();
		
			auto itEnd = ShapeComposite::m_shapeList.end();
			
			std::cout << "Points in your PolyLine: " << std::endl;
			for (it2; it2 != it2End; it2++) {
				//std::cout << "(" << dynamic_pointer_cast<Point>(*it)->X() << "," << dynamic_pointer_cast<Point>(*it)->Y() << ")" << "\n";
				(*it2)->Print();
			}
			std::cout << "\nPolyLine has ";
			return pnt.str();
		}
		
		template<template<typename, typename> class Container, typename alloc>
		ostream& operator << (ostream& os, const PolyLine<Container, alloc>& pl) { 
			os << pl.Print();
			return os;
		}

		template<template<typename, typename> class Container, typename alloc>
		void PolyLine<Container, alloc>::Draw() const { // Draw.
			std::cout << "PolyLine Draw function call.";
		}
		template<template<typename, typename> class Container, typename alloc>
		void PolyLine<Container, alloc>::CreatePolyLine() {
			bool keepGoing = true;
			char response;
			while (keepGoing) {
				std::cout << "Would you like to add a point to your PolyLine (y/n) ?" << std::endl;
				cin >> response;
				if (response == 'y') {
					double x = rand() % 100 + 1; //number from 1 to 100 for x coordinate
					double y = rand() % 100 + 1; //similar for y coordinate.
					Point p(x, y);
					std::cout << "Point added: " << p.ToString() << std::endl;
					std::shared_ptr<Point> pPtr = std::make_shared<Point>(p);
					std::shared_ptr<Shape> shapePtr = std::make_shared<Shape>(p);
					m_ptContainer.push_back(pPtr);
					ShapeComposite::AddShape(shapePtr);
				}
				else {
					std::cout << "Thank you for creating your PolyLine." << std::endl;
					keepGoing = false;
				}

			}



		}

		//template<template<typename, typename> class Container, typename alloc>
		//std::shared_ptr<Shape> PolyLine<Container, alloc>::Clone() const {
		//	PolyLine newPL(*this);
		//	std::shared_ptr<Shape> result = std::make_shared<Shape>(newPL);
		//	return result;
		//}
		
	}//namespace CAD
} //namespace PAULLOPEZ

#endif
