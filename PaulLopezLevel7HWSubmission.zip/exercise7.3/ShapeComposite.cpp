#ifndef ShapeComposite_CPP
#define ShapeComposite_CPP
#define _USE_MATH_DEFINES
#include "ShapeComposite.hpp"
#include "ShapeVisitor.hpp"
#include <cmath>
#include <sstream>

namespace PAULLOPEZ {
	namespace CAD {

		ShapeComposite::ShapeComposite() {}

		ShapeComposite::ShapeComposite(const ShapeComposite& srcShapeList) {
			//m_shapeList = srcShapeList.m_shapeList;
			auto iter = srcShapeList.m_shapeList.begin();
			while (iter != srcShapeList.m_shapeList.end()) {
				m_shapeList.push_back(*iter);
				iter++;
			}
		}// copy constructor

		ShapeComposite& ShapeComposite::operator = (const ShapeComposite& srcShapeList) {
			if (this == &srcShapeList) {
				return *this;
			}
			auto iter = srcShapeList.m_shapeList.begin();
			while (iter != srcShapeList.m_shapeList.end()) {
				m_shapeList.push_back(*iter);
				iter++;
			}
			return *this;
		}// Assignment operator


		//std::shared_ptr<Shape> ShapeComposite::Clone() const {
		//	ShapeComposite newSC(*this);
		//	std::shared_ptr<Shape> result = std::make_shared<Shape>(newSC);
		//	return result;
		//}

		void ShapeComposite::Accept(ShapeVisitor& sv) {
			for (auto iter = m_shapeList.begin(); iter != m_shapeList.end(); iter++) {
				ShapeComposite sc = *this;
				sv.visit(sc);
			}
		}

	}
}
#endif
