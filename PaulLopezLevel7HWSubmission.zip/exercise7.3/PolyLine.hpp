#ifndef PolyLine_HPP
#define PolyLine_HPP
#include <iostream>
#include <string>
#include "ShapeComposite.hpp"
#include "Point.hpp"
#include <memory>
using namespace std;

namespace PAULLOPEZ {
	namespace CAD {

		template<template<typename, typename> class Container, typename alloc = std::allocator<std::shared_ptr<Point>>>
		class PolyLine : public ShapeComposite { 
		private:
			Container<std::shared_ptr<Point>, alloc> m_ptContainer; //store my points in generic container
		public:
			PolyLine(); //default constructor will be polyline with container with no points
				
			PolyLine(int num, std::shared_ptr<Point> p); //initialize with num number of points, all of pointer point p

			~PolyLine(); //destructor

			string ToString() const; //returns cout string description of the point
			void Draw() const;

			//double Distance() const; //calc dist from current point to origin
			//double Distance(Point& p1) const; //calc dist from curr pt to point passed in function
			//std::shared_ptr<Shape> Clone() const;
			void CreatePolyLine();

			friend ostream& operator << (ostream& os, const PolyLine& pl);

		};
	}
}

#ifndef PolyLine_cpp // Must be the same name as in source file #define
#include "PolyLine.cpp"
#endif


#endif