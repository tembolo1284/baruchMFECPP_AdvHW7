#include <iostream>
#include <stdio.h>
#include <tuple>
#include <vector>
#include <functional>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include "Shape.hpp"
#include "OriginPoint.hpp"
#include "NewShapeFactory.hpp"
#include "ShapeComposite.hpp"
#include "ConsoleShapeFactory.hpp"
#include "PrintVisitor.hpp"
#include "PolyLine.hpp"

using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;

std::shared_ptr<Circle> circle_func() {
double radius;
double x;
double y;
std::cout << "Please input a radius for your circle (double)." << std::endl;
std::cin >> radius;
std::cout << "Please specify x coordinate for the center of your circle." << std::endl;
std::cin >> x;
std::cout << "Please specify y coordinate for the center of your circle." << std::endl;
std::cin >> y;
Point p(x, y);
Circle c1(radius, p);
std::shared_ptr<Circle> c1Ptr = std::make_shared<Circle>(c1);
c1Ptr->Print();
return c1Ptr;
}
std::shared_ptr<Line> line_func() {
	double x1;
	double y1;
	double x2;
	double y2;
	std::cout << "Please specify x coordinate for the first point." << std::endl;
	std::cin >> x1;
	std::cout << "Please specify y coordinate for the first point." << std::endl;
	std::cin >> y1;
	std::cout << "Please specify x coordinate for the second point." << std::endl;
	std::cin >> x2;
	std::cout << "Please specify y coordinate for the second point." << std::endl;
	std::cin >> y2;
	Point p1(x1, y1);
	Point p2(x2, y2);
	Line l1(p1, p2);
	std::shared_ptr<Line> l1Ptr = std::make_shared<Line>(l1);
	l1Ptr->Print();
	return l1Ptr;
}

int main() {
	//double a = 2.25;
	//Point p1(1, 2);
	//Point p2(-1, 3);
	//Point p3(0, 5);
	//Line l1(p1, p2);
	//Line l2(p2, p3);
	//Circle c1(a, p1);

	/*

	auto ptFunc = []() {
		double x;
		double y;
		std::cout << "Please specify x coordinate for the point." << std::endl;
		std::cin >> x;
		std::cout << "Please specify y coordinate for the point." << std::endl;
		std::cin >> y;
		Point p(x, y);
		std::shared_ptr<Point> pPtr = std::make_shared<Point>(p);
		pPtr->Print();
		return pPtr;
	};

	std::function<std::shared_ptr<Point>()> func_point = ptFunc; //lambda
	std::function<std::shared_ptr<Line>()> func_line = line_func; //free function
	std::function<std::shared_ptr<Circle>()> func_circle = std::bind(circle_func); //bind

	NewShapeFactory nsf1 (func_point, func_line, func_circle); //initialize new shape factory
	//nsf1.CreatePoint(); //create shapes asking user to enter data
	//nsf1.CreateLine();
	//nsf1.CreateCircle();
	
	
	
	//code copied from prof code snippet
	std::shared_ptr<NewShapeFactory> factory(new NewShapeFactory(func_point, func_line, func_circle));
	double val1 = 3.0; //
	double val2 = 1.5;
	//auto facP1= [val](){ return Pointer<P1>(new P11(val)); };
	auto facP1 = [&val1, &val2, &factory]() {
		auto p1 = factory->CreateDefaultPoint();
		p1->X(val1); //here is where I make a new point and then change the values to val1 and val2. 
		p1->Y(val2);
		p1->Print(); //output to console.
		return p1; };

	std::function<std::shared_ptr<Point>()> newPointFunc = facP1; 
	
	//in my case it just spits out a new point (3.0, 1.5) or whatever you make val1 and val2.  Very cool!
	//std::cout << facP1();

	ConsoleShapeFactory csf1;
	csf1.CreateLine();  
	*/
	//Point polyPt(1, 2);
	//std::shared_ptr<Point> polyPtPtr = std::make_shared<Point>(polyPt);
	//PolyLine <std::vector> pline1(5,polyPtPtr);
	
	PolyLine <std::vector> pline;
	pline.CreatePolyLine(); //type y or n to keep creating or stop creating random points to add to polyline.
	//Instead of randomly creating points, I could have asked the user to enter data.
	pline.Print(); //prints every point that has been added to your polyline.

	return 0;
}