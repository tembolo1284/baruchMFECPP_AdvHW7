#ifndef CONSOLESHAPEFACTORY_HPP
#define CONSOLESHAPEFACTORY_HPP
#include <iostream>
#include <string>
#include <memory>
#include "ShapeFactory.hpp"

namespace PAULLOPEZ {
	namespace CAD {
		class ConsoleShapeFactory : public ShapeFactory {

		public:
			std::shared_ptr<Circle> CreateCircle() override;
			
			std::shared_ptr<Line> CreateLine() override;
			
			std::shared_ptr<Point> CreatePoint() override;

			std::tuple<Point, Line, Circle> CreateShapes() override;
			
			virtual ~ConsoleShapeFactory() {}
		};

	}
}


#endif