#ifndef Counter_HPP
#define Counter_HPP
#include "Subject.hpp"

class Observer;
class Counter : public Subject {
	using SubjectFunction = std::function<void(Subject&)>;
private:
	int counterCount;
public:

	Counter();
	~Counter();

	int GetCounter();
	void IncreaseCounter(Observer* ob);
	void DecreaseCounter(Observer* ob);
	void IncreaseCounter(std::shared_ptr<SubjectFunction> ob);
	void DecreaseCounter(std::shared_ptr<SubjectFunction> ob);
};

//#ifndef Counter_cpp // Must be the same name as in source file #define
//#include "Counter.cpp"
//#endif

#endif