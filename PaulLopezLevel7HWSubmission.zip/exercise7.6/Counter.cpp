#ifndef Counter_CPP
#define Counter_CPP
#include "Counter.hpp"
#include "Observer.hpp"
#include <iostream>

Counter::Counter() : counterCount(0) {}

Counter::~Counter() {}

int Counter::GetCounter() {
	return counterCount;
}

void Counter::IncreaseCounter(Observer* ob) {
	counterCount += 1;
	std::cout << "Counter increased by 1." << std::endl;
	Subject::Notify(ob);
}

void Counter::DecreaseCounter(Observer* ob) {
	counterCount -= 1;
	std::cout << "Counter decreased by 1." << std::endl;
	Subject::Notify(ob);
}

void Counter::IncreaseCounter(std::shared_ptr<SubjectFunction> ob) {
	counterCount += 1;
	std::cout << "Counter increased by 1." << std::endl;
	Subject::Notify(ob);
}

void Counter::DecreaseCounter(std::shared_ptr<SubjectFunction> ob) {
	counterCount -= 1;
	std::cout << "Counter decreased by 1." << std::endl;
	Subject::Notify(ob);
}


#endif