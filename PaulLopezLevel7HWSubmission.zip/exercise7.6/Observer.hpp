#ifndef Observer_HPP
#define Observer_HPP
#include "Subject.hpp"
#include "Counter.hpp"
#include <iostream>

class Observer {
	using SubjectFunction = std::function<void(Subject&)>;
public:
	//Observer();
	//~Observer();
		
	//virtual void Update(Subject* s) = 0;
	void Update(Subject* s) {
		Counter* c = new Counter;
		c = dynamic_cast<Counter*>(s);
		std::cout << "Counter value is: " << c->GetCounter() << std::endl;
	}

	/*void Update(std::shared_ptr<SubjectFunction> s) {
		Counter* c = new Counter;
		c = dynamic_cast<Counter*>(s);
		std::cout << "Counter value is: " << c->GetCounter() << std::endl;
	}*/  //can't take this anywhere from what I can see
	
};

//#ifndef Observer_cpp // Must be the same name as in source file #define
//#include "Observer.cpp"
//#endif

#endif