#include "Counter.hpp"
#include "Observer.hpp"
//#include "LongFormat.hpp"
//#include "DoubleFormat.hpp"
#include "Subject.hpp"
#include <vector>
#include <iostream>
#include <functional>

//no longer need LongFormat hpp and cpp files
//This is part a not using template template params yet.
int main() {
	using SubjectFunction = std::function<void(Subject&)>;
	Counter c1;
	Counter c2;

	auto LambdaFunc = [](Subject& s) {std::cout << "Lambda function call";};

	SubjectFunction func1 = std::bind(LambdaFunc, c1);
	SubjectFunction func2 = std::bind(LambdaFunc, c2);

	std::shared_ptr<SubjectFunction> sfPtr1 = std::make_shared<SubjectFunction>(func1);
	std::shared_ptr<SubjectFunction> sfPtr2 = std::make_shared<SubjectFunction>(func2);

	c1.Attach(sfPtr1);
	c1.IncreaseCounter(sfPtr1); //will increase counter by 1 and iterate over the one SubjectFunction
	c1.Attach(sfPtr2);
	c1.IncreaseCounter(sfPtr2); //will increase counter to 2 and iterate over both SubjectFunctions in the list
	c1.IncreaseCounter(sfPtr2);
	c1.Detach_FuncWrapper(); //drops last guy in list
	c1.DecreaseCounter(sfPtr2); //decreases counter to 2 and iterates over last remaining SubFunc in the list.


	

	
	


	return 0;
}