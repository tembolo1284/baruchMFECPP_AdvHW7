#ifndef Subject_CPP
#define Subject_CPP
#include <vector>
#include <iostream>
#include "Subject.hpp"
#include "Observer.hpp"

Subject::Subject() {}
Subject::~Subject() {}

void Subject::Attach(Observer* ob) {
	std::cout << "Subject Attach vec call." << std::endl;
	m_vec.push_back(ob);
}

void Subject::Attach(std::shared_ptr<SubjectFunction> ob) {
	std::cout << "Subject Attach list call." << std::endl;
	m_list.push_back(ob);
}

void Subject::Detach() {
	std::cout << "Subject Detach call." << std::endl;
	m_vec.pop_back();
}

void Subject::Detach_FuncWrapper() {
	std::cout << "Subject Detach FuncWrapper call." << std::endl;
	m_list.pop_back();
}

void Subject::Notify(Observer* ob) {
	std::cout << "Subject Notify call." << std::endl;
	for (auto elem : m_vec) {
		elem->Update(this);
	}
}

void Subject::Notify(std::shared_ptr<SubjectFunction> ob) {
	std::cout << "Subject Notify func wrapper call." << std::endl;
	Observer ob1;
	for (auto iter = m_list.begin(); iter != m_list.end(); iter++) {
		ob1.Update(this);
		//ob1.Update(*iter); //nowhere to go with this guy.
	}
}

#endif