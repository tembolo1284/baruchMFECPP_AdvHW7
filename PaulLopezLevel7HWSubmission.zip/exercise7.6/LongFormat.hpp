#ifndef LongFormat_HPP
#define LongFormat_HPP
#include "Subject.hpp"
#include "Observer.hpp"

class LongFormat: public Observer {
public:

	void Update(Subject* s);

};

//#ifndef Observer_cpp // Must be the same name as in source file #define
//#include "Observer.cpp"
//#endif

#endif