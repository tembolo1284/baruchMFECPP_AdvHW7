#ifndef Subject_HPP
#define Subject_HPP
#include <vector>
#include <list>
#include <functional>
#include <memory>


class Observer;

class Subject {
	using SubjectFunction = std::function<void(Subject&)>;

private:
	std::vector<Observer*> m_vec;

protected:
	std::list<std::shared_ptr<SubjectFunction>> m_list;
public:
	
	Subject();
	~Subject();

	virtual void Attach(Observer* ob);
	void Attach(std::shared_ptr<SubjectFunction> ob);
	void Detach();
	void Detach_FuncWrapper();
	void Notify(Observer* ob);
	void Notify(std::shared_ptr<SubjectFunction> ob);
};



//#ifndef Subject_cpp // Must be the same name as in source file #define
//#include "Subject.cpp"
//#endif

#endif