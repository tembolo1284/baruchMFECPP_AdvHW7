#include <random>
#include <memory>
#include <cmath>
#include <iostream>
#include <concepts>
#include "OptionData.hpp" // in local directory
#include "StopWatch.hpp"
#include "SDEAbstract.hpp"
#include "SDEGBM.hpp"
#include "SDEGBMPoisson.hpp"
//in the original SDE class below, you were stuck with a drift of (r - D)*S and diffusion term of sigma*S.
// SDE for this class is always dS_t = (r - D) * S_t * dt + sigma * S_t * dW_t
//we have no option to change any coefficients of dt or dW, unless we hardcode it below or copy it.

/*For SDEAbstract I created an abstract class of what I have below, and I create an inherited class
for each specific SDE I want to tackle.  For something like Heston or a multi-asset model,
since i'm dealing with more than one SDE, i'll have to be able to handle multiple equations at once.
I'm starting to think of a vector/matrix way to handle them. So instead of just 1 SDE
dS_t = ... we'll have a vector/matrix of S_1....S_N.  I'm going to try and break that up
for the final project where we have 1-dim and greater than 1-dim implementations.  
I might just stick to explicit although if that's too painful I'll give an implicit implementation a try.
*/

//Kept this to test results against it
class SDE { // Defines drift + diffusion + data

private:
    std::shared_ptr<OptionData> data; // The data for the option

public:
    SDE(const OptionData& optionData) : data(new OptionData(optionData)) {}

    double drift(double t, double S) { // Drift term
        return (data->r - data->D) * S; // r - D
    }

    double diffusion(double t, double S) { // Diffusion term
        return data->sig * S;
    }
};

int main() {

    std::cout << "1 factor MC with explicit Euler\n";
    OptionData myOption{ 65.0, 0.25, 0.08, 0.3, 0.0, -1 }; // -1 for put
    OptionData myOption2{ 65.0, 0.25, 0.08, 0.3, 0.0, -1 }; // -1 for put
    std::shared_ptr<OptionData> optPtr = std::make_shared<OptionData>(myOption);
    std::shared_ptr<OptionData> optPtr2 = std::make_shared<OptionData>(myOption2);

    //create same as prof duffy sde but through derived class of SDEAbsract
    SDEGBM<shared_ptr<OptionData>, double> sdeGBM(optPtr);

    //create SDEGBM but with Poisson jumpy jump
    double lambda{ 0.25 };
    SDEGBMPoisson<shared_ptr<OptionData>, double> sdeGBMPoisson(optPtr2, lambda);

    /*
    std::cout << "K: " << myOption.K << std::endl; //65.0
    std::cout << "T: " << myOption.T << std::endl; //0.25
    std::cout << "r: " <<myOption.r << std::endl; //0.08
    std::cout << "sigma: " << myOption.sig << std::endl; //0.3
    std::cout << "D: " <<myOption.D << std::endl; // 0.0
    std::cout << "type: " << myOption.type << std::endl; // -1
    */
    //std::cout << sdeGBM.drift(2.5, 2.5);  //r - D = 0.08, r = 0.08, D = 0.0   

    /* myOption.K = 65.0;
      myOption.T = 0.25;
      myOption.r = 0.08;
      myOption.sig = 0.3;
      myOption.D = 0.0;
      myOption.type = -1; // Put -1, Call +1*/

      /*myOption.K = 100.0;
       myOption.T = 1.0;
       myOption.r = 0.0;
       myOption.sig = 0.2;
       myOption.D = 0.0;
       myOption.type = -1; // Put -1, Call +1
       */

    //original prof Duffy way
    SDE sde(myOption);

    // Initial value of SDE
    double S_0 = 60;
    // Variables for underlying stock

    double x;
    double VOld = S_0;
    double VNew{ 0.0 };
    long NT = 100;

    std::cout << "Number of time steps: ";
    std::cin >> NT;

    // V2 mediator stuff
    long NSIM = 50000;
    std::cout << "Number of simulations: ";
    std::cin >> NSIM;

    double M = static_cast<double>(NSIM);
    double dt = myOption.T / static_cast<double> (NT);
    double sqrdt = std::sqrt(dt);

    // Normal random number
    double dW{ 0.0 };
    double dJ{ 0.0 }; //jump variable for poisson
    double price{ 0.0 }; // Option price
    double payoffT{ 0.0 };
    double avgPayoffT{ 0.0 };
    double squaredPayoff{ 0.0 };
    double sumPriceT {0.0};

    // #include <random>     // Normal (0,1) rng
    std::default_random_engine dre;
    std::normal_distribution<double> nor(0.0, 1.0);
    // Create a random number
    dW = nor(dre);

    //Poisson number generator
    std::default_random_engine generator;
    std::poisson_distribution<int> poissonDistr(lambda); //lambda initialized above. Set to 0.25
    dJ = poissonDistr(generator);

    StopWatch sw;
    sw.StartStopWatch();

    for (long i = 1; i <= M; ++i) {
        // Calculate a path at each iteration
        if ((i / 100'000) * 100'000 == i) {
            // Give status after each 10000th iteration
            std::cout << i << ", ";
        }

        VOld = S_0;
        x = 0.0;
        for (long index = 0; index <= NT; ++index) {
            // Create a random number for brownian motion and for poisson
            dW = nor(dre);
            dJ = poissonDistr(generator);
           
            //some sanity check stuff
            //std::cout << "sde.diffusion(x, VOld): " << sde.diffusion(x, VOld) << std::endl;
            //std::cout << "sdeGBM.diffusion(x, VOld): " << sdeGBM.diffusion(x, VOld) << std::endl;

            // The FDM (in this case explicit Euler) 
            //S_n+1 = S_n + (dt * drift) + (sqrt(dt)* diffusion * dW)
            
            //1. uncomment this to use original SDE class in main (original prof duffy way)
            //VNew = VOld + (dt * sde.drift(x, VOld)) + (sqrdt * sde.diffusion(x, VOld) * dW);
            
            //2. uncomment this to use SDEGBM from new SDEAbstract derived classes SDEGBM
            //VNew = VOld + (dt * sdeGBM.drift(x, VOld)) + (sqrdt * sdeGBM.diffusion(x, VOld) * dW);

            //3. uncomment this to use SDEGBMPoisson from new SDEAbstract derived classes SDEGBMPoisson
            //slightly tweaked SDE euler numerical implementation
            VNew = VOld + (dt * sdeGBMPoisson.drift(x, VOld)) + (sqrdt * sdeGBMPoisson.diffusion(x, VOld) * dW) + (sdeGBMPoisson.jump(x, VOld) * dJ * sqrdt * dW);
            VOld = VNew;
            x += dt;
        }

        //I could have created extra variables VNewGBM, VNewGBMPoisson and such so they could all be run at the same time.
        //Or give the option to the user which one they want to run. Something I plan to clean up for final project for sure.
        // Assemble quantities (postprocessing)
        payoffT = myOption.myPayOffFunction(VNew);
        sumPriceT += payoffT;
        avgPayoffT += payoffT / M;
        avgPayoffT *= avgPayoffT;
        squaredPayoff += (payoffT * payoffT);
    }

    // Finally, discounting the average price
    price = std::exp(-myOption.r * myOption.T) * (sumPriceT / M); // exp(-rT) * avgPayoffT
    std::cout << "Price, after discounting: " << price << ", " << std::endl;

    double SD = std::sqrt((squaredPayoff / M) - sumPriceT * sumPriceT / (M * M));

    std::cout << "Standard Deviation: " << SD << ", " << std::endl;
    double SE = SD / std::sqrt(M);
    std::cout << "Standard Error: " << SE << ", " << std::endl;
    sw.StopStopWatch();

    std::cout << "Elapsed time in seconds: " << sw.GetTime() << '\n';

    return 0;

}

//poisson testing stuff

/* int p[10] = {};
    const int nrolls = 10000; // number of experiments
    const int nstars = 100;   // maximum number of stars to distribute
    for (int i = 0; i < nrolls; ++i) {
        int number = poissonDistr(generator);
        if (number < 10) ++p[number];
    }

    std::cout << "poisson_distribution (mean=0.5):" << std::endl;
    for (int i = 0; i < 10; ++i)
        std::cout << i << ": " << std::string(p[i] * nstars / nrolls, '*') << std::endl;*/