#ifndef SDEGBM_HPP
#define SDEGBM_HPP
#include <concepts>
#include <memory>
#include "OptionData.hpp"
#include "SDEAbstract.hpp"
template <typename T, typename Data> 
class SDEGBM : public SDEAbstract<shared_ptr<OptionData>, double> {

private:
    T _t;

public:
    //dS_t = (r-D) * S_t dt + sig * S_t * dZ_t
    SDEGBM(const T& t) : _t(t) {}

    Data diffusion(Data t, Data x) const {
        return (*_t).sig * x;  //diffusion(t, x);
    }
    Data drift(Data t, Data x) const {
        return ((*_t).r - (*_t).D) * x;  //drift(t, x);
    }
    Data jump(Data t, Data x) const {
        return 0.0; // jump(t, x);
    }
};

//#ifndef SDEGBM_cpp // Must be the same name as in source file #define
//#include "SDEGBM.cpp"
//#endif

#endif
