#ifndef SDEGBM_CPP
#define SDEGBM_CPP
// Interface contract specification
#include <concepts>
#include <memory>
#include "SDEGBM.hpp"


    //black scholes basic SDE assumption: dS_t = mu*S_t*dt + sigma*S_t*dX_t
    template <typename T, typename Data>
    SDEGBM<T,Data>::SDEGBM(const T& t) : _t(t), SDEAbstract<shared_ptr<OptionData>, double>(T& t) {}

    template <typename T, typename Data>
    Data SDEGBM<T,Data>::diffusion(Data t, Data x) const {
        return (* this->_t.sig * x);  //diffusion(t, x);

    }

    template <typename T, typename Data>
    Data SDEGBM<T,Data>::drift(Data t, Data x) const {
        return (*this->_t.r - *this->_t.D);  //drift(t, x);
       // T _t = *this->InstrumentInfo();
       // return _t->r - _t->D;
    }

    template <typename T, typename Data>
    Data SDEGBM<T, Data>::jump(Data t, Data x) const {
        return 0.0; // *this->jump(t, x);
    }



#endif
