#ifndef SDEAbstract_HPP
#define SDEAbstract_HPP
// Interface contract specification
#include <concepts>
#include <memory>
#include "OptionData.hpp"

template<typename T, typename Data>
concept IDiffusion = requires (T c, Data t, Data x)  //"dX coefficient"
{ c.diffusion(t, x); };

template<typename T, typename Data>
concept IDrift = requires (T c, Data t, Data x)  //"dt coefficient"
{ c.drift(t, x); };

template<typename T, typename Data>
concept IJump = requires (T c, Data t, Data x) // "dJ or "Jump" coefficient
{ c.jump(t, x); };

template<typename T, typename Data>
concept IDriftDiffusion = IDiffusion<T, Data> && IDrift<T, Data>;

template<typename T, typename Data>
concept IDriftDiffusionJump = IDiffusion<T, Data> && IDrift<T, Data> && IJump<T, Data>;

template <typename T, typename Data> 
//requires IDriftDiffusionJump<T, Data>
class SDEAbstract { 

private:
    T _t;
public:
    //SDEAbstract(const T& t) : _t(t) {}

    //interface functions that need to be impl in all derived classes
    virtual Data diffusion(Data t, Data x) const = 0;
    virtual Data drift(Data t, Data x) const = 0;
    virtual Data jump(Data t, Data x) const = 0;
};

//#ifndef SDEAbstract_cpp // Must be the same name as in source file #define
//#include "SDEAbstract.cpp"
//#endif
#endif
