#ifndef SDEGBMPoisson_HPP
#define SDEGBMPoisson_HPP
#include <concepts>
#include <memory>
#include "OptionData.hpp"
#include "SDEAbstract.hpp"
template <typename T, typename Data>
class SDEGBMPoisson : public SDEAbstract<shared_ptr<OptionData>, double> {
private:
    T _t;
    Data lambda;

public:
    /*dS_t = (r - D) * S_t dt + sig * S_t * dZ_t + dJ_t <-- - the "jump term" is 1 in my case here,
    but I can make it anything * dJ_t.  In theory I should be able to make it any function 
    f(S_t, t) * dJ_t.  If a jump occurs between t and t+1 that'll be the term I add to the
    original SDE.*/

    SDEGBMPoisson(const T& t, const Data& lam) : _t(t), lambda(lam) {}

    Data diffusion(Data t, Data x) const {
        return (*_t).sig * x;  //diffusion(t, x);
    }
    Data drift(Data t, Data x) const {
        return ((*_t).r - (*_t).D) * x;  //drift(t, x);
    }
    Data jump(Data t, Data x) const {
        return x; // jump(t, x);
    }
};

//#ifndef SDEGBMPoisson_cpp // Must be the same name as in source file #define
//#include "SDEGBMPoisson.cpp"
//#endif


#endif
