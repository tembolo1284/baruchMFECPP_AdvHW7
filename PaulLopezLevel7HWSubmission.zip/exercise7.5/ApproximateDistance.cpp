#ifndef ApproximateDistance_CPP
#define ApproximateDistance_CPP
#include <iostream>
//#include "Point.hpp"
//#include "Shape.hpp"
#include "ApproximateDistance.hpp"
#include "DistanceStrategy.hpp"

namespace PAULLOPEZ {
	namespace CAD {

		//using PointDistanceFnType = std::function<double(Point p1, Point p2)>;

		double ApproximateDistance::Distance(const Point& p1, const Point& p2) {
			//std::cout << "Approximate Distance Method -> ";
			//double result = abs(p2.X() - p1.X()) + abs(p2.Y() - p1.Y()); 
			//auto func = this->GetFunc();
			double result = _func(p1, p2);
			counter++;
			return result;
		}
	}
}

#endif