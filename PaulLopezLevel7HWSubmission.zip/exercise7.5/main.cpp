#include <iostream>
#include <functional>
#include "Point.hpp"
#include "Shape.hpp"
#include "DistanceStrategy.hpp"
#include "ApproximateDistance.hpp"
#include "ExactDistance.hpp"

using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;

int main() {
	using PointDistanceFnType = std::function<double (Point p1, Point p2)>;

	auto ExactDistLambda = [](Point p1, Point p2) -> double {
		std::cout << "Exact Distance Lambda: ";
		double result = sqrt(pow(p2.X() - p1.X(), 2.0) + pow(p2.Y() - p1.Y(), 2.0)); // ((x2-x1)^2 + (y2-y1)^2)^0.5
		return result;
	};

	auto ApproxDistLambda = [](Point p1, Point p2) -> double {
		std::cout << "Approximate Distance Lambda: ";
		double result = abs(p2.X() - p1.X()) + abs(p2.Y() - p1.Y());
		return result;
	};


	Point p1(1, 2);
	Point p2(2, -1);

	PointDistanceFnType funcExact = std::bind(ExactDistLambda, p1, p2);
	PointDistanceFnType funcApprox = std::bind(ApproxDistLambda, p1, p2);
	//std::cout << "p1 to origin = " << p1.Distance() << std::endl;
	//std::cout << "p1 to p2 = " << p1.Distance(p2) << std::endl;
	//p1.SetStrategy("Approx");

	DistanceStrategy* dsExact = new ExactDistance;
	DistanceStrategy* dsApprox = new ApproximateDistance;
	dsExact->switchFunction(funcExact);
	dsApprox->switchFunction(funcApprox);

	std::cout << "p1 to p2 = " << p1.Distance(p2, *dsExact) << std::endl;
	std::cout << "p1 to p2 = " << p1.Distance(p2, *dsApprox) << std::endl;

	//////////////function wrapper way

	DistanceStrategy* dsFuncWrapper(dsExact);
	dsFuncWrapper->GetCounter(); //0

	std::cout << dsFuncWrapper->Distance(p1, p2) << std::endl;
	dsFuncWrapper->GetCounter(); //	1

	dsFuncWrapper->switchFunction(funcApprox);
	std::cout << dsFuncWrapper->Distance(p1, p2) << std::endl;
	dsFuncWrapper->GetCounter(); //2

	//One thing I could tweak is the dsFuncWrapper is an instance of the ExactDistance class in my example.
	//My function wrapper attached to the lambda can change, but the object is still that of an exactDistance class.
	//While the flexibility is nice it could be confusing for the user. I'd probably make a choice to do it only one way.
	//The generality of it is very cool though. 
	

	return 0;
}