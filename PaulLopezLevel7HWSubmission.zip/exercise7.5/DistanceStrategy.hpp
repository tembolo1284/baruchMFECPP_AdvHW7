#ifndef DistanceStrategy_HPP
#define DistanceStrategy_HPP
#include <iostream>
#include <functional>
//#include "Point.hpp"
//#include "Shape.hpp"


namespace PAULLOPEZ {
	namespace CAD {

		
		class Point; // fwd declare Point
		class DistanceStrategy {

			using PointDistanceFnType = std::function<double(Point p1, Point p2)>;

		//private:
		protected:
			PointDistanceFnType _func;
			size_t counter;
		public:
			
			DistanceStrategy() : counter(0) { }
			
			DistanceStrategy(PointDistanceFnType& function) {
				_func = function;
				counter = 0;
			}
			virtual double Distance(const Point& p1, const Point& p2) = 0;

			//double Distance(const Point& p1, const Point& p2) {
			//	auto result = _func(p1, p2);
			//	return result;
			//}
			
			void switchFunction(const PointDistanceFnType function) {
			_func = function;
			}
			
			void GetCounter() {
				std::cout << "Current counter value: " << counter << std::endl;
			}

			PointDistanceFnType GetFunc() {
				return _func;
			}

		};
	}
}

#endif