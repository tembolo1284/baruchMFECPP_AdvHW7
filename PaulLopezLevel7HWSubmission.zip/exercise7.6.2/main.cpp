#include "Counter.hpp"
#include "Subject.hpp"
#include <vector>
#include <iostream>
#include <functional>
#include <deque>

//no longer need observer hpp and doubleFormat/LongFormat hpp and cpp files
int main() {
	
	using SubjectFunction = std::function<void(double)>;
	Counter<std::deque> c1;

	double a = 1.5;
	auto LambdaFunc = [](double a) {std::cout << "Lambda function call";};

	SubjectFunction func1 = std::bind(LambdaFunc, a);
	SubjectFunction func2 = std::bind(LambdaFunc, a);

	std::shared_ptr<SubjectFunction> sfPtr1 = std::make_shared<SubjectFunction>(func1);
	std::shared_ptr<SubjectFunction> sfPtr2 = std::make_shared<SubjectFunction>(func2);

	c1.Attach(sfPtr1);
	c1.IncreaseCounter(sfPtr1); //will increase counter by 1 and iterate over the one SubjectFunction
	c1.Attach(sfPtr2);
	c1.IncreaseCounter(sfPtr2); //will increase counter to 2 and iterate over both SubjectFunctions in the list
	c1.DecreaseCounter(sfPtr2); //decreases counter to 1 and iterates over last remaining SubFunc in the list.
	c1.Attach(sfPtr2); //attaching again
	c1.IncreaseCounter(sfPtr2); //end with counter value of 2
	
	return 0;
}