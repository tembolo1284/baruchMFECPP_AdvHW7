#ifndef Subject_CPP
#define Subject_CPP
#include <vector>
#include <iostream>
#include "Subject.hpp"
//#include "Observer.hpp"
#include "Counter.hpp"
#include <memory>

template<template<typename, typename> class Container, typename alloc>
Subject<Container, alloc>::Subject() {}

template<template<typename, typename> class Container, typename alloc>
Subject<Container, alloc>::~Subject() {}

template<template<typename, typename> class Container, typename alloc>
void Subject<Container, alloc>::Attach(std::shared_ptr<SubjectFunction> ob) {
	std::cout << "Subject Attach list call." << std::endl;
	//m_list.push_back(ob);
	m_observerList.push_back(ob);
}

template<template<typename, typename> class Container, typename alloc>
void Subject<Container, alloc>::Detach() {
	std::cout << "Subject Detach call." << std::endl;
	//m_vec.pop_back();
	m_observerList.pop_back();
}

template<template<typename, typename> class Container, typename alloc>
void Subject<Container, alloc>::Notify(std::shared_ptr<SubjectFunction> ob) {
	//Observer ob1;
	std::cout << "Subject Notify func wrapper call." << std::endl;

	//Couldn't get this sucker to work.
	
	//for (auto iter = m_observerList.begin(); iter != m_observerList.end(); iter++) { //iterator through container
	//	std::cout << "Current counter value: " << std::dynamic_pointer_cast<Counter<Container, alloc>>(this)->GetCounter() << std::endl;
	//}
}



//(*iter)(dynamic_pointer_cast<Counter<std::deque>*>(this)->GetCounter()); //first try
		//(*it)(dynamic_cast<Counter<T,Container,Alloc>*>(this)->GetCounter());//vladimir's code from discussion board
		//Observer ob1;
		//ob1.Update(this);
		// 
//old stuff moved to bottom for posterity

//void Subject::Attach(Observer* ob) {
//	std::cout << "Subject Attach vec call." << std::endl;
//	m_vec.push_back(ob);
//}

//void Subject::Detach_FuncWrapper() {
//	std::cout << "Subject Detach FuncWrapper call." << std::endl;
//	m_list.pop_back();
//}

//void Subject::Notify(Observer* ob) {
//	std::cout << "Subject Notify call." << std::endl;
//	for (auto elem : m_vec) {
//		elem->Update(this);
//	}
//}



#endif