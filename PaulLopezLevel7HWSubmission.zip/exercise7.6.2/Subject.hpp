#ifndef Subject_HPP
#define Subject_HPP
#include <vector>
#include <list>
#include <deque>
#include <functional>
#include <memory>

using SubjectFunction = std::function<void(double)>; //changed this to void(double) from void(Subject&) previously

class Observer; //fwd ref

template<template<typename, typename> class Container, typename alloc = std::allocator<std::shared_ptr<SubjectFunction>>>
class Subject {
	
private:
	//std::vector<Observer*> m_vec; //just commenting out the old stuff so you can see how/what I had
	Container<std::shared_ptr<SubjectFunction>, alloc> m_observerList;

//protected:
	//std::list<std::shared_ptr<SubjectFunction>> m_list;
public:
	
	Subject();
	~Subject();

	//virtual void Attach(Observer* ob);
	virtual void Attach(std::shared_ptr<SubjectFunction> ob);
	void Detach();
	//void Detach_FuncWrapper();
	//void Notify(Observer* ob);
	void Notify(std::shared_ptr<SubjectFunction> ob);
};



#ifndef Subject_cpp // Must be the same name as in source file #define
#include "Subject.cpp"
#endif

#endif