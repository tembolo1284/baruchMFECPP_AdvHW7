#ifndef Observer_CPP
#define Observer_CPP
#include "Subject.hpp"
#include "Counter.hpp"
#include "Observer.hpp"
#include <iostream>
#include <memory>
#include <deque>

//template<template<typename, typename> class Container, typename alloc> // = std::allocator<std::shared_ptr<SubjectFunction>> >
//class Counter;


	//using SubjectFunction = std::function<void(double&)>;


	void Update(Subject<std::deque>* s) {
		std::cout << "Update Function call." << std::endl;
		//std::cout << "Counter value is: " << dynamic_cast<Counter<std::deque>*>(s)->GetCounter();
		//std::cout << "Counter value is: " << c->GetCounter() << std::endl;
	}

	//Observer() {}
	//~Observer() {}
	//virtual void Update(Subject* s) = 0;


//#ifndef Observer_cpp // Must be the same name as in source file #define
//#include "Observer.cpp"
//#endif

#endif