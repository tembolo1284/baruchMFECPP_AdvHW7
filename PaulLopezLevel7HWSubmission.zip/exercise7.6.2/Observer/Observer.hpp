#ifndef Observer_HPP
#define Observer_HPP
#include "Subject.hpp"
#include "Counter.hpp"
#include <iostream>
#include <memory>
#include <deque>

class Observer {
	using SubjectFunction = std::function<void(double&)>;
public:

	void Update(Subject<std::deque>* s);// {
	//std::cout << "Counter value is: " << dynamic_cast<Counter<std::deque, std::allocator<std::shared_ptr<SubjectFunction>>>*>(s)->GetCounter();
		//std::cout << "Counter value is: " << c->GetCounter() << std::endl;
	//}	

	//Observer() {}
	//~Observer() {}
	//virtual void Update(Subject* s) = 0;
};

//#ifndef Observer_cpp // Must be the same name as in source file #define
//#include "Observer.cpp"
//#endif

#endif