#ifndef Counter_CPP
#define Counter_CPP
#include "Counter.hpp"
//#include "Observer.hpp"
#include <iostream>

template<template<typename, typename> class Container, typename alloc>
Counter<Container,alloc>::Counter() : counterCount(0) {}

template<template<typename, typename> class Container, typename alloc>
Counter<Container,alloc>::~Counter() {}

template<template<typename, typename> class Container, typename alloc>
int Counter<Container, alloc>::GetCounter() {
	return counterCount;
}
template<template<typename, typename> class Container, typename alloc>
void Counter<Container, alloc>::IncreaseCounter(std::shared_ptr<SubjectFunction> ob) {
	counterCount += 1;
	std::cout << "Counter increased by 1." << std::endl;
	//this->Notify(ob);
	std::cout << "Current Counter value: " << this->GetCounter() << std::endl;
	//Subject<Container, alloc>::Notify(ob);
}
template<template<typename, typename> class Container, typename alloc>
void Counter<Container, alloc>::DecreaseCounter(std::shared_ptr<SubjectFunction> ob) {
	counterCount -= 1;
	std::cout << "Counter decreased by 1." << std::endl;
	//this->Notify(ob); //would have liked to go to observer class to do the casting and call to GetCounter from there
	//but couldn't get it to work quite right
	std::cout << "Current Counter value: " << this->GetCounter() << std::endl;
	//Subject<Container, alloc>::Notify(ob);
}


//////////////////////////////

//void Counter::IncreaseCounter(Observer* ob) {
//	counterCount += 1;
//	std::cout << "Counter increased by 1." << std::endl;
//	Subject::Notify(ob);
//}

//void Counter::DecreaseCounter(Observer* ob) {
//	counterCount -= 1;
//	std::cout << "Counter decreased by 1." << std::endl;
//	Subject::Notify(ob);
//}



#endif