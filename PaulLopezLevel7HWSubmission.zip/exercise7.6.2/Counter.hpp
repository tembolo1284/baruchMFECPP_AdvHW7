#ifndef Counter_HPP
#define Counter_HPP
#include "Subject.hpp"

class Observer;
using SubjectFunction = std::function<void(double)>;

template<template<typename, typename> class Container, typename alloc = std::allocator<std::shared_ptr<SubjectFunction>>>
class Counter: public Subject<Container, alloc> {

private:
	int counterCount;
	Container<std::shared_ptr<SubjectFunction>, alloc> m_observerList;

public:

	Counter();
	~Counter();

	int GetCounter();
	void IncreaseCounter(std::shared_ptr<SubjectFunction> ob);
	void DecreaseCounter(std::shared_ptr<SubjectFunction> ob);
	//void IncreaseCounter(Observer* ob);
	//void DecreaseCounter(Observer* ob);
	
};

#ifndef Counter_cpp // Must be the same name as in source file #define
#include "Counter.cpp"
#endif

#endif