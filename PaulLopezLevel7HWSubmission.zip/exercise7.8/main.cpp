import StructExample;
import Line;
//import Point;
#include <iostream>

int main() {
	Point p1(1, 1);
	Point p2(3, 3);
	std::cout << "p1 distance to origin: " << p1.Distance() << std::endl;
	p2.Draw();

	Line l1(p1, p2);
	std::cout << "l1 length = " << l1.Length() << std::endl;
	l1.Draw();

	Point p3 = p1 + p2;
	std::cout << "p3 distance to p2: " << p3.Distance(p2) << std::endl << std::endl;



	S s;
	s.do_stuff(); // prof duffy example
	

	return 0;
}
