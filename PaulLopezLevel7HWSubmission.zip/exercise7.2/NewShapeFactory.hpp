#ifndef NEWSHAPEFACTORY_HPP
#define NEWSHAPEFACTORY_HPP
#include <iostream>
#include <string>
#include "Point.hpp"
#include "Line.hpp"
#include "Circle.hpp"
#include <memory>
#include <functional>


namespace PAULLOPEZ {
	namespace CAD {

		class NewShapeFactory {

		private:
			std::function<std::shared_ptr<Point>()> m_func_point;
			std::function<std::shared_ptr<Line>()> m_func_line;
			std::function<std::shared_ptr<Circle>()> m_func_circle;

		public:
			NewShapeFactory();
			NewShapeFactory(const std::function<std::shared_ptr<Point>()>& func_point, 
				const std::function<std::shared_ptr<Line>()>& func_line, 
				const std::function<std::shared_ptr<Circle>()>& func_circle);

			//void CreateCircle(std::function<std::shared_ptr<Circle>()>& circleFunc);
			//void CreateLine(std::function<std::shared_ptr<Line>()>& lineFunc);
			//void CreatePoint(std::function<std::shared_ptr<Point>()>& pointFunc);

			std::shared_ptr<Circle> CreateCircle();
			std::shared_ptr<Line> CreateLine();
			std::shared_ptr<Point> CreatePoint();
			std::shared_ptr<Point> CreateDefaultPoint();
			//virtual std::tuple<Point, Line, Circle> CreateShapes() = 0;

			virtual ~NewShapeFactory() {}
		};
	}
}

#endif