#ifndef CONSOLESHAPEFACTORY_CPP
#define CONSOLESHAPEFACTORY_CPP
#include <iostream>
#include <string>
#include <memory>
#include <tuple>
#include "ConsoleShapeFactory.hpp"
//#include "Point.hpp"
//#include "Line.hpp"
//#include "Circle.hpp"
//#include "Shape.hpp"

namespace PAULLOPEZ {
	namespace CAD {


		std::tuple<Point, Line, Circle> ConsoleShapeFactory::CreateShapes() {
			Point p1(1, 1);
			Point p2(0, 0);
			Line l1(p1, p2);
			Circle c1(1.5, p1);
			return std::make_tuple(p1, l1, c1);
		} //in this case will always return hard-coded point, line, and circle that I made just for this exercise
		//Could also ask user to enter values like in functions below, or take them as params to the function.


		std::shared_ptr<Circle> ConsoleShapeFactory::CreateCircle() {
			double radius;
			double x;
			double y;
			std::cout << "Please input a radius for your circle (double)." << std::endl;
			std::cin >> radius;
			std::cout << "Please specify x coordinate for the center of your circle." << std::endl;
			std::cin >> x;
			std::cout << "Please specify y coordinate for the center of your circle." << std::endl;
			std::cin >> y;
			Point p(x, y);
			Circle c1(radius, p);
			std::shared_ptr<Circle> c1Ptr = std::make_shared<Circle>(c1);
			//*c1Ptr = c1;
			c1Ptr->Print();
			return c1Ptr;
		}

		std::shared_ptr<Line> ConsoleShapeFactory::CreateLine() {
			double x1;
			double y1;
			double x2;
			double y2;
			std::cout << "Please specify x coordinate for the first point." << std::endl;
			std::cin >> x1;
			std::cout << "Please specify y coordinate for the first point." << std::endl;
			std::cin >> y1;
			std::cout << "Please specify x coordinate for the second point." << std::endl;
			std::cin >> x2;
			std::cout << "Please specify y coordinate for the second point." << std::endl;
			std::cin >> y2;
			Point p1(x1, y1);
			Point p2(x2, y2);
			Line l1(p1, p2);
			std::shared_ptr<Line> l1Ptr = std::make_shared<Line>(l1);
			l1Ptr->Print();
			return l1Ptr;

		}

		std::shared_ptr<Point> ConsoleShapeFactory::CreatePoint() {
			double x;
			double y;
			std::cout << "Please specify x coordinate for the point." << std::endl;
			std::cin >> x;
			std::cout << "Please specify y coordinate for the point." << std::endl;
			std::cin >> y;
			Point p(x, y);
			std::shared_ptr<Point> pPtr = std::make_shared<Point>(p);
			pPtr->Print();
			return pPtr;
		
		}

	}
}
#endif