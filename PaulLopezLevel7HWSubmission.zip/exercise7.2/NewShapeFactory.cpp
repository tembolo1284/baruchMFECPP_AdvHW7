#ifndef NEWSHAPEFACTORY_CPP
#define NEWSHAPEFACTORY_CPP
#include <iostream>
#include <string>
#include <memory>
#include <tuple>
#include <functional>
#include "NewShapeFactory.hpp"

namespace PAULLOPEZ {
	namespace CAD {

		NewShapeFactory::NewShapeFactory() {}

		NewShapeFactory::NewShapeFactory(const std::function<std::shared_ptr<Point>()>& func_point, 
			const std::function<std::shared_ptr<Line>()>& func_line, 
			const std::function<std::shared_ptr<Circle>()>& func_circle) {

			m_func_point = func_point;
			m_func_line = func_line;
			m_func_circle = func_circle;
		}

		std::shared_ptr<Circle> NewShapeFactory::CreateCircle() {
			return m_func_circle();
		}

		std::shared_ptr<Line> NewShapeFactory::CreateLine() {
			return m_func_line();
		}

		std::shared_ptr<Point> NewShapeFactory::CreatePoint() {
			return m_func_point();
		}

		std::shared_ptr<Point> NewShapeFactory::CreateDefaultPoint() {
			std::shared_ptr<Point> pPtr;
			Point p(0, 0);
			pPtr = std::make_shared<Point>(p);
			return pPtr;
		}

	}
}
#endif