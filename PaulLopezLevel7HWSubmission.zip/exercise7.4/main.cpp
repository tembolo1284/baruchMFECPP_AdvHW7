#include <iostream>
#include <chrono>
#include <functional>
#include <thread>
#include <future>
#include <atomic>
#include "TmpProcessor.hpp"


//atomic int and functions to be used for multithreaded futures solution of tmpProcessors

std::atomic<int> result1Fut{ 2 };
std::atomic<int> result2Fut{ 5 };
std::atomic<int> result3Fut{ 7 };
std::atomic<int> result4Fut{ 10 };

int FuncF1FutFactory(int& result1Fut) {
	std::cout << "\nThis is func F1 fut factory value: " << result1Fut << std::endl;
	return result1Fut;
}

int FuncF1fut(std::future<int>& fut) {
	result1Fut = fut.get() * 2;
	for (int i = 0; i < 1'500'000'000; i++) {}
	std::cout << "\nThis is func F1 fut compute value: " << result1Fut << std::endl;
	return result1Fut;
}

int FuncF1FutDispatch(int& result1Fut) {
	std::cout << "\nThis is func F1 fut dispatch value: " << result1Fut << std::endl;
	return result1Fut;
}

int FuncF2FutFactory(int& result2Fut) {
	std::cout << "\nThis is func F2 fut factory value: " << result2Fut << std::endl;
	return result2Fut;
}

int FuncF2fut(std::future<int>& fut) {
	result2Fut = fut.get() * 3;
	std::this_thread::sleep_for(std::chrono::milliseconds(500));
	std::cout << "\nThis is func F2 fut compute value: "<< result2Fut << std::endl;
	return result2Fut;
}
int FuncF2FutDispatch(int& result2Fut) {
	std::cout << "\nThis is func F2 fut dispatch value: " << result2Fut << std::endl;
	return result2Fut;
}

int FuncF3FutFactory(int& result3Fut) {
	std::cout << "\nThis is func F3 fut factory value: " << result3Fut << std::endl;
	return result3Fut;
}

int FuncF3fut(std::future<int>& fut) {
	int result3Fut =fut.get() * 7;
	std::this_thread::sleep_for(std::chrono::milliseconds(500));
	std::cout << "\nThis is func F3 fut compute value: " << result3Fut << std::endl;
	return result3Fut;
}

int FuncF3FutDispatch(int& result3Fut) {
	std::cout << "\nThis is func F3 fut dispatch value: " << result3Fut << std::endl;
	return result3Fut;
}

int FuncF4FutFactory(int& result4Fut) {
	std::cout << "\nThis is func F4 fut factory value: " << result4Fut << std::endl;
	return result4Fut;
}

int FuncF4fut(std::future<int>& fut) {
	result4Fut = fut.get() * 10;
	std::this_thread::sleep_for(std::chrono::milliseconds(500));
	std::cout << "This is func F4 fut compute value: " << result4Fut << std::endl;
	return result4Fut;
}

int FuncF4FutDispatch(int& result4Fut) {
	std::cout << "This is func F4 fut dispatch value: " << result4Fut << std::endl;
	return result4Fut;
}
int main() {
	//ints and lambdas to be used for single thread method of tmpProcessor
	int a = 2;
	int b = 3;
	int c = 7;
	int d = 10;

	auto FactoryFunc = [](int a) -> int {
		std::cout << "Factory Func F1 input: " << a << std::endl;
		return a;
	};

	auto ComputeFuncF1 = [](int a) -> int {
		for (int i = 0; i < 500'000'000; i++) {}
		std::cout << "This is Computefunc F1" << std::endl;
		return a * 2;
	};

	auto DispatchFuncF1 = [](int a) {
		std::cout << "This is Dispatch func F1 output: " << a << std::endl;
		return a;
	};

	auto ComputeFuncF2 = [](int a) -> int {
		for (int i = 0; i < 500'000'000; i++) {}
		std::cout << "This is Computefunc F2" << std::endl;
		return a * 3;
	};

	auto DispatchFuncF2 = [](int a) {
		std::cout << "This is Dispatch func F2 output: " << a << std::endl;
		return a;
	};

	auto ComputeFuncF3 = [](int a) -> int {
		for (int i = 0; i < 500'000'000; i++) {}
		std::cout << "This is Computefunc F3" << std::endl;
		return a * 10;
	};

	auto DispatchFuncF3 = [](int a) {
		std::cout << "This is Dispatch func F3 output: " << a << std::endl;
		return a;
	};


	auto ComputeFuncF4 = [](int a) -> int {
		for (int i = 0; i < 500'000'000; i++) {}
		std::cout << "This is Computefunc F4" << std::endl;
		return a * 10;
	};

	auto DispatchFuncF4 = [](int a) {
		std::cout << "This is Dispatch func F4 output: " << a << std::endl;
		return a;
	};

	//single thread method/////////////////////////////
	FactoryFunction<int> factFunc1 = FactoryFunc; 
	ComputeFunction<int, int> compFunc1 = ComputeFuncF1;
	DispatchFunction<int> dispatchFunc1 = DispatchFuncF1;

	FactoryFunction<int> factFunc2 = FactoryFunc; 
	ComputeFunction<int, int> compFunc2 = ComputeFuncF2; 
	DispatchFunction<int> dispatchFunc2 = DispatchFuncF2;

	FactoryFunction<int> factFunc3 = FactoryFunc; 
	ComputeFunction<int, int> compFunc3 = ComputeFuncF3;
	DispatchFunction<int> dispatchFunc3 = DispatchFuncF3;

	FactoryFunction<int> factFunc4 = FactoryFunc; 
	ComputeFunction<int, int> compFunc4 = ComputeFuncF4;
	DispatchFunction<int> dispatchFunc4 = DispatchFuncF4;
	
	//create instances of single thread.  SingleThreadMethod() will be run along with futures method below
	TmpProcessor<int, int> tmpP(factFunc1, compFunc1, dispatchFunc1);
	//tmpP.SingleThreadMethod();  
	TmpProcessor<int, int> tmpP2(factFunc2, compFunc2, dispatchFunc2);
	//tmpP2.SingleThreadMethod();
	TmpProcessor<int, int> tmpP3(factFunc3, compFunc3, dispatchFunc3);
	//tmpP3.SingleThreadMethod(); 
	TmpProcessor<int, int> tmpP4(factFunc4, compFunc4, dispatchFunc4);
	//tmpP4.SingleThreadMethod(); 
	//////////////
	


	///////futures method

	FactoryFunction<int> factMultiThreadFunc1 = &FuncF1FutFactory; //factory 
	ComputeFunction<int, std::future<int>> compMultiThreadFunc1 = FuncF1fut; //compute
	DispatchFunction<int> dispatchMultiThreadFunc1 = &FuncF1FutDispatch; //dispatch

	FactoryFunction<int> factMultiThreadFunc2 = &FuncF2FutFactory; //factory 
	ComputeFunction<int, std::future<int>> compMultiThreadFunc2 = FuncF2fut; //compute
	DispatchFunction<int> dispatchMultiThreadFunc2 = &FuncF2FutDispatch; //dispatch

	FactoryFunction<int> factMultiThreadFunc3 = &FuncF3FutFactory; //factory 
	ComputeFunction<int, std::future<int>> compMultiThreadFunc3 = FuncF3fut; //compute
	DispatchFunction<int> dispatchMultiThreadFunc3 = &FuncF3FutDispatch; //dispatch

	FactoryFunction<int> factMultiThreadFunc4 = &FuncF4FutFactory; //factory 
	ComputeFunction<int, std::future<int>> compMultiThreadFunc4 = FuncF4fut; //compute
	DispatchFunction<int> dispatchMultiThreadFunc4 = &FuncF4FutDispatch; //dispatch

	//futures solution tmpProcessor set up. Method is below alternating between single thread method and parallel futs method
	TmpProcessor<int, std::future<int>> tmpMulti1(factMultiThreadFunc1, compMultiThreadFunc1, dispatchMultiThreadFunc1);
	//tmpMulti1.ParallelFuturesMethod();

	TmpProcessor<int, std::future<int>> tmpMulti2(factMultiThreadFunc2, compMultiThreadFunc2, dispatchMultiThreadFunc2);
	//tmpMulti2.ParallelFuturesMethod();
	
	TmpProcessor<int, std::future<int>> tmpMulti3(factMultiThreadFunc3, compMultiThreadFunc3, dispatchMultiThreadFunc3);
	//tmpMulti3.ParallelFuturesMethod();
	
	TmpProcessor<int, std::future<int>> tmpMulti4(factMultiThreadFunc4, compMultiThreadFunc4, dispatchMultiThreadFunc4);
	//tmpMulti4.ParallelFuturesMethod();


	/////////// Let 'er rip!

	tmpP.SingleThreadMethod();
	tmpMulti1.ParallelFuturesMethod();
	tmpP2.SingleThreadMethod();
	tmpMulti2.ParallelFuturesMethod();
	tmpP3.SingleThreadMethod();
	tmpMulti3.ParallelFuturesMethod();
	tmpP4.SingleThreadMethod();
	tmpMulti4.ParallelFuturesMethod(); 


	return 0;
}