#ifndef TMPPROCESSOR_HPP
#define TMPPROCESSOR_HPP
#include <functional>
#include <stdlib.h>

template <typename T>
using FactoryFunction = std::function<T(T& t)>;
template <typename T, typename U>
using ComputeFunction = std::function<T(U& u)>;
template <typename T>
using DispatchFunction = std::function<T(T& t)>;

// Class with Input-Processing-Output
template <typename T,typename U>
class TmpProcessor { // No inheritance used
private:
    FactoryFunction<T> _factory;
    ComputeFunction<T,U> _compute;
    DispatchFunction<T> _dispatch;

public:
    TmpProcessor(const FactoryFunction<T>& factory,
             const ComputeFunction<T, U>& compute,
             const DispatchFunction<T>& dispatch) : _factory(factory), _compute(compute), _dispatch(dispatch) {}

    void SingleThreadMethod() {
        int x = rand() % 100 + 1; //number from 1 to 100 to start process and feed factory.
        int f = _factory(x);
        int c = _compute(f);
        _dispatch(c);
    }

        
      void ParallelFuturesMethod()  { 
          // Parallel with futures
          std::promise<int> promiseCompute;
          std::future<int> futCompute = promiseCompute.get_future();

          int x = rand() % 100 + 1;
        
          std::thread tFactory(std::bind(_factory, x));
          std::thread tCompute(_compute, std::ref(futCompute));
          promiseCompute.set_value(x);

          std::thread tDispatch(std::bind(_dispatch, x*2));
          tFactory.join();
          tCompute.join();
          tDispatch.join();
      }
};


#endif